//---------------------------------------- begin tap_highlight.js
// necessary to remove gray touch highlight

document.addEventListener("touchstart", function(){}, true); // -webkit-tap-highlight-color: rgba(100,0,0,0);

//---------------------------------------- end tap_highlight.js
