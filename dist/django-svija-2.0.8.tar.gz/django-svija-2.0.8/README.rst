=====
Svija
=====

A set of tools for building web sites using Adobe Illustrator.
The most important part is a CMS for managing pages and menus.

Detailed documentation is in the "docs" directory.

Visit https://svija.com for an overview of the project.

Quick start
-----------

1. Add "svija" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'svija',
    ]

2. You'll need to modify your project settings and urls according to

    https://github.com/svija-svg/generic-site

   There are some other files to upload included in that repository.

3. Visit https://docs.svija.com for detailed installation information.
