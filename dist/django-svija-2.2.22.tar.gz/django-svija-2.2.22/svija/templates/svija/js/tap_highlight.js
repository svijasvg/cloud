//———————————————————————————————————————— template: tap_highlight.js

// removes or modifies gray touch highlight on mobile
// add CSS to set color
// -webkit-tap-highlight-color: rgba(100,0,0,0);

document.addEventListener("touchstart", function(){}, true);
