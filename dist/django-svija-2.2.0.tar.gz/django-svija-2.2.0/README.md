*Modified 6 May, 2021 · live server*

![Svija: SVG-based websites built in Adobe Illustrator](http://files.svija.love/github/readme-logo.png "Svija: SVG-based websites built in Adobe Illustrator")

**Svija: web sites with SVG instead of HTML**
---------------------------------------------

Version 2.2.0

A set of tools for building web sites using Adobe Illustrator.
Includes a CMS for managing pages and menus.

Detailed documentation is available at **[docs.svija.love][1]**

Visit **[svija.love][2]** for an overview of the project.

If you're interested, we can help you set up an account for free.
Just go to our **[contact page][3]** and ask!

[1]: https://docs.svija.love "Visit the documentation site"
[2]: https://svija.love "Visit the main site"
[3]: https://svija.love/en/contact "Contact us"
