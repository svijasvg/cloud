#———————————————————————————————————————— LinksView.py
#
#   NOTE: missing images are 1x1 — barely visible in the browser
#
#   Links folder redirection breaks if the prefix does not exist
#   instead of defaulting to en, need to get site default section
#
# return HttpResponse("debugging message.")

from django.core.exceptions import ObjectDoesNotExist
from django.http import FileResponse, HttpResponse
from django.shortcuts import get_object_or_404
from os.path import exists
from svija.models import Settings
from urllib.parse import unquote

import unicodedata, os

def LinksView(request, request_prefix, img_file):

  request_prefix = unquote(request_prefix)
  img_file = unquote(img_file)

#———————————————————————————————————————— path

  sync_folder = os.path.abspath(os.path.dirname(__name__)) + '/SYNC/'
  img_path    = request_prefix + '/' + img_file

#———————————————————————————————————————— normalize for accents

  path_parts     = img_path.split('/')
  path_parts_nfd = [unicodedata.normalize("NFD", p) for p in path_parts]
  img_path = os.path.join(sync_folder, *path_parts_nfd)

#———————————————————————————————————————— does file exist?
# see also Error404.py

  if not exists(img_path):
    ext      = img_file.split('.')[-1].lower()
    img_path = os.getcwd() + '/static/svija/img/ff0000.'+ ext
    img      = open(img_path, 'rb')

    response = FileResponse(img)
    response.status_code = 404
    return response

#———————————————————————————————————————— return file contents

  img = open(img_path, 'rb')
  response = FileResponse(img)
  return response


#———————————————————————————————————————— fin

