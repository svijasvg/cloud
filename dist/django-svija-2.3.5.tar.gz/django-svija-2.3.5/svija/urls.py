#———————————————————————————————————————— urls.py

#———————————————————————————————————————— imports

from . import views
from django.contrib import admin
from django.urls import path, re_path, include
from django.views import static
from django.views.static import serve # DO I NEED THIS?
import os

#———————————————————————————————————————— from home/xxx/urls.py

admin.autodiscover()
admin.site.enable_nav_sidebar = False

#———————————————————————————————————————— variables

proj_folder = os.path.abspath(os.path.dirname(__name__))

app_name = 'svija'

# for images in Links folder PREVIOUS
#   image_folder = '[A-Za-z0-9À-ÖØ-öø-ÿ_ \.\/-]*Links'
#   image_file = '[A-Za-z0-9À-ÖØ-öø-ÿ_ \.-]+\.(jpeg|jpg|png|gif)'

# "../../Links/shadow drop.png"

image_folder = '.*Links'                  # image folder
image_file = '.*\.(jpeg|jpg|png|gif)'   # image file

# https://www.regular-expressions.info/modifiers.html


#:::::::::::::::::::::::::::::::::::::::: url patterns

urlpatterns = [ 

#———————————————————————————————————————— from /home/xxx/urls.py

#   re_path(r'^', include('svija.urls', namespace="svija")),

#———————————————————————————————————————— exact addresses

    path('cloud.css',   views.CloudCSSView  ),
    path('csync',       views.ClearCacheView),   # Sync + Admin top bar
    path('mail',        views.MailView      ),
    path('send',        views.SendView      ),   # send test mail to see what happens
    path('robots.txt',  views.RobotsView    ),
    path('sitemap.txt', views.SitemapView   ),

#———————————————————————————————————————— images in Links folder
#
#   accepts any path ending in Links › / › any path ending in .jpg etc.
#
#   at top of this file:
#
#   image_folder = '.*Links'                  # image folder
#   image_file = '.*\.(jpeg|jpg|png|gif)'   # image file

    re_path(r'^(?P<request_prefix>' + image_folder + ')/(?P<img_file>' + image_file + ')$', views.LinksView),

#———————————————————————————————————————— SVG pages

    path('',                                   views.PageView),   # prefix/slug
    path('<slug:section_url>',                 views.PageView),   # prefix/slug
    path('<slug:section_url>/<slug:page_url>', views.PageView),   # prefix/slug

#———————————————————————————————————————— redirects

#   redirects are handled by Error404.py
#   that filename is determined by urls.py in the site project folders

#———————————————————————————————————————— fonts, icons & scripts

    re_path(r'^fonts/(?P<path>.*)$',         static.serve, {'document_root': proj_folder + "/SYNC/SYSTEM/Fonts/WOFF Files" }),
    re_path(r'^files/(?P<path>.*)$',         static.serve, {'document_root': proj_folder + "/SYNC/SYSTEM/Shared Files"     }),
    re_path(r'^images/(?P<path>.*)$',        static.serve, {'document_root': proj_folder + "/SYNC/SYSTEM/Images"           }),

]

#———————————————————————————————————————— fin
