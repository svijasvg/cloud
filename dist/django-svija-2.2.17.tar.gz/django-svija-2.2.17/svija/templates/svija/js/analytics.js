window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
if (tracking_on || getCookie('acceptsCookies')==1)
  gtag('config', '{{ analytics_id }}');


