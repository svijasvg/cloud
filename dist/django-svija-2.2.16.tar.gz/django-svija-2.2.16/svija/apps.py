from django.apps import AppConfig


class SvgPagesConfig(AppConfig):
    name = 'svija'
    verbose_name = 'Svija'
