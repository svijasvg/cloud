//———————————————————————————————————————— template: responsive.js

// mobile is portrait & desktop is landscape

var languages = [];

languages['port'] = [];
languages['port']['fr'] = 'fm';
languages['port']['en'] = 'em';

languages['land'] = [];
languages['land']['fm'] = 'fr';
languages['land']['em'] = 'en';

//————— is window portrait or landscape?

var cutoff = 0.9;

var ratio = window.innerWidth / window.innerHeight;
var isPort = false;
if (ratio < cutoff) isPort = true;

//————— get url information

var parts = page_url.split('/');
var lng = parts[3];
var pge = parts[4];
    pge = pge.replace('#', '');

//————— is page portrait or landscape?

var pgPort = false;
if (lng.indexOf('m') > 0) pgPort = true;

//————— redirections

// redirect from landscape to portrait
if (isPort && !pgPort){
    location.href = '/' + languages['port'][lng] + '/' + pge;
    }

// redirect from portrait to landscape
if (!isPort && pgPort){
    location.href = '/' + languages['land'][lng] + '/' + pge;
}
