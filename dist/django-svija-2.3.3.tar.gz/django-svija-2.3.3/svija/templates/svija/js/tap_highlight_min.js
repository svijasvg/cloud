document.addEventListener("touchstart",function(){},!0);
