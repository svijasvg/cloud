
//:::::::::::::::::::::::::::::::::::::::: template: tap_highlight.js
/*
https://www.toptal.com/developers/javascript-minifier
*/

/*———————————————————————————————————————— notes

    removes or modifies gray touch highlight on mobile

    add CSS to set color
    -webkit-tap-highlight-color: rgba(100,0,0,0); */


//:::::::::::::::::::::::::::::::::::::::: program

document.addEventListener("touchstart", function(){}, true);

//:::::::::::::::::::::::::::::::::::::::: fin

