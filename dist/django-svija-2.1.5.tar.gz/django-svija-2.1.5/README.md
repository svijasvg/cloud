![Svija: SVG-based websites built in Adobe Illustrator](http://files.svija.com/github/readme-logo.png "Svija: SVG-based websites built in Adobe Illustrator")

**Svija: web sites with SVG instead of HTML**
---------------------------------------------

Version 2.1.5

A set of tools for building web sites using Adobe Illustrator.
Includes a CMS for managing pages and menus.

Detailed documentation is available at **[docs.svija.com][1]**

Visit **[svija.com][2]** for an overview of the project.

If you're interested, we can help you set up a server for free.
Just go to our **[contact page][3]** and ask!

[1]: https://docs.svija.com "Visit the documentation site"
[2]: https://svija.com "Visit the main site"
[3]: https://svija.com/en/contact "Contact us"
